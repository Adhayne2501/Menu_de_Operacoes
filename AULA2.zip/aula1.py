#def funcao_oi(parametronome):
    #print(f"\noi {parametronome}")
#nome = input("Digite seu nome: ")
#funcao_oi(nome)
#def calcular(valorA, valorB):
        #resultado = valorA * valorB
        #print(f" O resultado é: {resultado}")
#valorA = int(input(" Digite um número: "))
#valorB = int(input(" Digite outro número: "))
#calcular(valorA, valorB)

#TODO PEÇA PARA O USUÁRIO DIGITAR 2 VALORES
#CHAME A FUNÇÃO CALCULAR
#TODO LER OS 2 NÚMEROS DO USUÀRIO
#TODO PERGUNTAR QUAL OPERAÇÃO MATEMÁTICA ELE DESEJA
#TODO (1) SOMAR, (2) SUBTRAIR, (3) MULTIPLICAR, (4) DIVIDIR
#TODO NO FINAL, EXIBIR O RESULTADO (PRINT)

def somar (valorA, valorB):
    resultado = valorA + valorB
    print(f" O resultado é: {resultado}")

def subtrair (valorA, valorB):
    resultado = valorA - valorB
    print(f" O resultado é: {resultado}")

def multiplicar (valorA, valorB):
    resultado = valorA * valorB
    print(f" O resultado é: {resultado}")

def dividir (valorA, valorB):
    resultado= valorA / valorB
    print(f" O resultado é: {resultado}")

print("(1) para somar ,(2) para subtrair , (3) para multiplicar , (4) para dividir ")
escolha_do_cliente = int(input (" Escolha uma operação: "))

if(escolha_do_cliente == 1):
    valorA = int(input(" Digite um número: "))
    valorB = int(input(" Digite outro número: "))
    somar(valorA, valorB)

elif(escolha_do_cliente == 2):
    valorA = int(input(" Digite um número: "))
    valorB = int(input(" Digite outro número: "))
    subtrair(valorA, valorB)

elif (escolha_do_cliente == 3):
    valorA = int(input(" Digite um número: "))
    valorB = int(input(" Digite outro número: "))
    multiplicar(valorA, valorB)

elif (escolha_do_cliente == 4):
    valorA = int(input(" Digite um número: "))
    valorB = int(input(" Digite outro número: "))
    dividir(valorA, valorB)

